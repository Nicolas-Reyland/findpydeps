from findpydeps import *
import sys
if __name__ == "__main__":
	sys.exit(main())